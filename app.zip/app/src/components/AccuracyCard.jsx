import React from "react";
import { RadialBarChart, RadialBar, Legend } from "recharts";
import Image from "next/image";

const AccuracyCard = ({
  logoSrc,
  name,
  id,
  date,
  time,
  accuracy,
  audioMatching,
  logoDetection,
}) => {
  const data = [
    {
      name: "Accuracy",
      value: accuracy,
      fill: "#4ade80",
    },
  ];

  return (
    <div className="max-w-sm rounded overflow-hidden shadow-lg bg-white p-4">
      <div className="flex items-center mb-4">
        <Image
          src={logoSrc}
          alt={name}
          width={40}
          height={40}
          className="rounded-full"
        />
        <div className="ml-4">
          <h2 className="font-bold text-xl">{name}</h2>
          <p className="text-gray-600 text-sm">ID-{id}</p>
        </div>
        <div className="ml-auto text-right">
          <p className="text-gray-600 text-sm">{time}</p>
          <p className="text-gray-600 text-sm">{date}</p>
        </div>
      </div>

      <div className="flex items-center justify-center">
        <RadialBarChart
          width={150}
          height={150}
          cx={75}
          cy={75}
          innerRadius={60}
          outerRadius={70}
          barSize={10}
          data={data}
        >
          <RadialBar
            minAngle={15}
            background
            clockWise={true}
            dataKey="value"
          />
          <Legend
            iconSize={0}
            width={120}
            height={140}
            layout="vertical"
            verticalAlign="middle"
            align="center"
          />
        </RadialBarChart>
        <div className="text-center">
          <h3 className="text-3xl font-bold">{accuracy}%</h3>
          <p className="text-gray-600">Accuracy</p>
        </div>
      </div>

      <div className="mt-4">
        <div className="mb-2">
          <span className="text-gray-700">Audio Matching</span>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div
              className="bg-blue-600 h-2.5 rounded-full"
              style={{ width: `${audioMatching}%` }}
            ></div>
          </div>
          <span className="float-right">{audioMatching}%</span>
        </div>
        <div>
          <span className="text-gray-700">Logo Detection</span>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div
              className="bg-purple-600 h-2.5 rounded-full"
              style={{ width: `${logoDetection}%` }}
            ></div>
          </div>
          <span className="float-right">{logoDetection}%</span>
        </div>
      </div>
    </div>
  );
};

export default AccuracyCard;
